package af.gov.momp.visitors

import android.app.*
import android.content.*
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

data class Visitor(
    val id: Int,
    val name: String,
    val father: String,
    val phone: String,
    val tazkira: String,
    val province: String,
    val district: String,
    val date: String,
    val time: String,
    val department: String,
    val subject: String,
    val responsible: String,
    val photo: String,
    val attachment: String,
    val note: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    var loggedIn by remember { mutableStateOf(false) }
    if (!loggedIn) LoginScreen { loggedIn = true } else MainScreen()
}

@Composable
fun LoginScreen(onLogin: () -> Unit) {
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Image(painterResource(R.drawable.ministry_logo), "لوګو", Modifier.size(130.dp))
        Spacer(Modifier.height(12.dp))
        Text("کندز ولایت د کانونو ریاست", style = MaterialTheme.typography.headlineSmall)
        Text("د مراجعینو د ثبت سیستم")
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(user, {user=it}, label={Text("کارن نوم")}, modifier=Modifier.fillMaxWidth())
        OutlinedTextField(pass, {pass=it}, label={Text("پاسورډ")}, visualTransformation=PasswordVisualTransformation(), modifier=Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        Button({ onLogin() }, Modifier.fillMaxWidth()) { Text("ننوتل") }
        Text("د لومړنۍ نسخې لپاره هر کارن/پاسورډ منل کېږي؛ د امنیتي نسخه کې به کارن مدیریت اضافه شي.", style=MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun MainScreen() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var page by remember { mutableStateOf("dashboard") }
    var visitors by remember { mutableStateOf(loadVisitors(ctx)) }
    var editing by remember { mutableStateOf<Visitor?>(null) }

    fun saveList(list: List<Visitor>) { visitors=list; saveVisitors(ctx,list) }

    Scaffold(
        topBar={TopAppBar(title={Text("کندز ولایت د کانونو ریاست")})},
        bottomBar={
            NavigationBar {
                NavigationBarItem(page=="dashboard",{page="dashboard"},{},{Text("Dashboard")})
                NavigationBarItem(page=="add",{page="add";editing=null},{},{Text("نوی مراجع")})
                NavigationBarItem(page=="list",{page="list"},{},{Text("مراجعین")})
                NavigationBarItem(page=="reports",{page="reports"},{},{Text("راپورونه")})
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad)) {
            when(page) {
                "dashboard" -> Dashboard(visitors)
                "add" -> VisitorForm(editing) { v ->
                    val list = if(editing==null) visitors + v else visitors.map{if(it.id==v.id)v else it}
                    saveList(list); page="list"; editing=null
                }
                "list" -> VisitorList(visitors, { v -> editing=v; page="add" }, { v ->
                    saveList(visitors.filter{it.id!=v.id})
                })
                "reports" -> Reports(visitors)
            }
        }
    }
}

@Composable
fun Dashboard(v: List<Visitor>) {
    val today=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
    val todayCount=v.count{it.date==today}
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("ښه راغلاست", style=MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            StatCard("ټول مراجعین",v.size.toString(),Modifier.weight(1f))
            StatCard("نن",todayCount.toString(),Modifier.weight(1f))
        }
        Spacer(Modifier.height(18.dp))
        Text("د مراجعینو د ثبت، لټون، تعدیل، حذف، PDF او Excel سیستم.", style=MaterialTheme.typography.bodyLarge)
    }
}
@Composable fun StatCard(t:String,v:String,m:Modifier)=Card(m){Column(Modifier.padding(16.dp)){Text(t);Text(v,style=MaterialTheme.typography.headlineMedium)}}

@Composable
fun VisitorForm(old: Visitor?, onSave:(Visitor)->Unit) {
    val ctx=androidx.compose.ui.platform.LocalContext.current
    var name by remember{mutableStateOf(old?.name?:"")}
    var father by remember{mutableStateOf(old?.father?:"")}
    var phone by remember{mutableStateOf(old?.phone?:"")}
    var taz by remember{mutableStateOf(old?.tazkira?:"")}
    var prov by remember{mutableStateOf(old?.province?:"")}
    var dist by remember{mutableStateOf(old?.district?:"")}
    var dept by remember{mutableStateOf(old?.department?:"")}
    var subject by remember{mutableStateOf(old?.subject?:"")}
    var resp by remember{mutableStateOf(old?.responsible?:"")}
    var note by remember{mutableStateOf(old?.note?:"")}
    var photo by remember{mutableStateOf(old?.photo?:"")}
    var attachment by remember{mutableStateOf(old?.attachment?:"")}
    val gallery=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()){u:Uri?->photo=u?.toString()?:""}
    val filePick=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()){u:Uri?->attachment=u?.toString()?:""}

    LazyColumn(Modifier.fillMaxSize().padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)) {
        item{Text(if(old==null)"د نوي مراجع ثبت" else "د مراجع معلومات تعدیل",style=MaterialTheme.typography.headlineSmall)}
        fun add(label:String,value:String,set:(String)->Unit,min:Int=1)=item{OutlinedTextField(value,set,label={Text(label)},modifier=Modifier.fillMaxWidth(),minLines=min)}
        add("نوم او تخلص",name,{name=it}); add("د پلار نوم",father,{father=it}); add("د اړیکې شمېره",phone,{phone=it})
        add("د تذکرې نمبر",taz,{taz=it}); add("ولایت",prov,{prov=it}); add("ولسوالي",dist,{dist=it})
        add("اداره / مدیریت",dept,{dept=it}); add("د راتګ موضوع او غوښتنه",subject,{subject=it},2); add("مسئول",resp,{resp=it}); add("اضافي یادښت",note,{note=it},3)
        item{
            Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                Button({gallery.launch("image/*")}){Text("📷 عکس")}; Button({filePick.launch("*/*")}){Text("📎 سند") }
            }
            if(photo.isNotBlank()) Text("عکس انتخاب شوی")
            if(attachment.isNotBlank()) Text("سند انتخاب شوی")
        }
        item{
            Button({
                if(name.isBlank()){Toast.makeText(ctx,"نوم ولیکئ",Toast.LENGTH_SHORT).show();return@Button}
                val now=Date()
                onSave(Visitor(old?.id ?: (System.currentTimeMillis()%100000000).toInt(),name,father,phone,taz,prov,dist,
                    old?.date?:SimpleDateFormat("yyyy-MM-dd",Locale.US).format(now),
                    old?.time?:SimpleDateFormat("HH:mm",Locale.US).format(now),dept,subject,resp,photo,attachment,note))
            },Modifier.fillMaxWidth()){Text("ثبت او ذخیره") }
        }
    }
}

@Composable
fun VisitorList(v:List<Visitor>, onEdit:(Visitor)->Unit, onDelete:(Visitor)->Unit) {
    var q by remember{mutableStateOf("")}
    var selected by remember{mutableStateOf<Visitor?>(null)}
    val f=v.filter{it.name.contains(q,true)||it.phone.contains(q,true)||it.tazkira.contains(q,true)||it.id.toString()==q}
    Column(Modifier.fillMaxSize().padding(14.dp)){
        Text("د مراجعینو لست",style=MaterialTheme.typography.headlineSmall)
        OutlinedTextField(q,{q=it},label={Text("نوم، تذکره، موبایل یا ثبت نمبر")},modifier=Modifier.fillMaxWidth())
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.padding(top=8.dp)){
            items(f){x->Card(Modifier.fillMaxWidth()){
                Column(Modifier.padding(12.dp)){
                    Text("ثبت نمبر: ${x.id}"); Text(x.name,style=MaterialTheme.typography.titleMedium); Text("موضوع: ${x.subject}"); Text("${x.date} ${x.time}")
                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                        Button({selected=x}){Text("معلومات")}; Button({onEdit(x)}){Text("تعدیل")}
                        OutlinedButton({onDelete(x)}){Text("حذف")}
                    }
                }
            }}
        }
    }
    selected?.let{x->
        AlertDialog(onDismissRequest={selected=null},title={Text("د مراجع بشپړ معلومات")},text={
            Column{Text("نوم: ${x.name}");Text("پلار: ${x.father}");Text("موبایل: ${x.phone}");Text("تذکره: ${x.tazkira}");Text("ولایت/ولسوالي: ${x.province}/${x.district}");Text("اداره: ${x.department}");Text("مسئول: ${x.responsible}");Text("موضوع: ${x.subject}");Text("یادښت: ${x.note}")}
        },confirmButton={Button({selected=null}){Text("بندول")}})
    }
}

@Composable
fun Reports(v:List<Visitor>) {
    val ctx=androidx.compose.ui.platform.LocalContext.current
    Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("راپورونه",style=MaterialTheme.typography.headlineSmall)
        Button({exportCsv(ctx,v) },Modifier.fillMaxWidth()){Text("📊 Excel-compatible CSV صادرول")}
        Button({exportPdf(ctx,v) },Modifier.fillMaxWidth()){Text("📄 PDF راپور جوړول")}
        Button({backup(ctx,v) },Modifier.fillMaxWidth()){Text("💾 Backup جوړول")}
    }
}

fun prefs(ctx:Context)=ctx.getSharedPreferences("visitors",Context.MODE_PRIVATE)
fun esc(s:String)=s.replace("\\","\\\\").replace("|","\\p").replace("\n"," ")
fun unesc(s:String)=s.replace("\\p","|").replace("\\\\","\\")
fun encode(v:Visitor)=listOf(v.id,v.name,v.father,v.phone,v.tazkira,v.province,v.district,v.date,v.time,v.department,v.subject,v.responsible,v.photo,v.attachment,v.note).joinToString("|"){esc(it.toString())}
fun decode(s:String):Visitor?=try{val a=s.split("|");Visitor(a[0].toInt(),*a.drop(1).map(::unesc).toTypedArray())}catch(_:Exception){null}
fun saveVisitors(c:Context,v:List<Visitor>){prefs(c).edit().putString("data",v.joinToString("\n",transform=::encode)).apply()}
fun loadVisitors(c:Context)=prefs(c).getString("data","")!!.lines().filter{it.isNotBlank()}.mapNotNull(::decode)

fun exportCsv(c:Context,v:List<Visitor>){
    val dir=c.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)!!
    val f=File(dir,"mراجعین_${System.currentTimeMillis()}.csv")
    f.writeText("ثبت نمبر,نوم,پلار نوم,موبایل,تذکره,ولایت,ولسوالي,نېټه,وخت,اداره,موضوع,مسئول,یادښت\n"+
        v.joinToString("\n"){listOf(it.id,it.name,it.father,it.phone,it.tazkira,it.province,it.district,it.date,it.time,it.department,it.subject,it.responsible,it.note).joinToString(","){ "\""+it.replace("\"","\"\"")+"\"" }})
    Toast.makeText(c,"Excel فایل جوړ شو: ${f.name}",Toast.LENGTH_LONG).show()
}
fun exportPdf(c:Context,v:List<Visitor>){
    val pdf=android.graphics.pdf.PdfDocument(); var page=1; var y=60f
    var p=pdf.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(595,842,page).create()); var cv=p.canvas
    val paint=android.graphics.Paint().apply{textSize=12f}
    cv.drawText("Kunduz Mines - Visitors Report",40f,35f,paint)
    v.forEach{
        if(y>800){pdf.finishPage(p);page++;p=pdf.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(595,842,page).create());cv=p.canvas;y=40f}
        cv.drawText("${it.id} | ${it.name} | ${it.phone} | ${it.date} | ${it.subject}",30f,y,paint);y+=20
    }
    pdf.finishPage(p)
    val f=File(c.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"visitors_${System.currentTimeMillis()}.pdf");f.outputStream().use{pdf.writeTo(it)};pdf.close()
    Toast.makeText(c,"PDF جوړ شو: ${f.name}",Toast.LENGTH_LONG).show()
}
fun backup(c:Context,v:List<Visitor>){
    val f=File(c.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),"backup_${System.currentTimeMillis()}.txt")
    f.writeText(v.joinToString("\n",transform=::encode))
    Toast.makeText(c,"Backup جوړ شو: ${f.name}",Toast.LENGTH_LONG).show()
}
